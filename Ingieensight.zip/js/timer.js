// Tounament 1
var countDownDate = new Date("Sep 30, 2017 10:00:00").getTime();

                                                // Update the count down every 1 second
var x = setInterval(function() {

// Get todays date and time
var now = new Date().getTime();

// Find the distance between now an the count down date
var distance = countDownDate - now;

// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);

// Display the result in the element with id="demo"
document.getElementById("days").innerHTML = days;
document.getElementById("hours").innerHTML = hours;
document.getElementById("minutes").innerHTML = minutes;
document.getElementById("seconds").innerHTML = seconds;

// If the count down is finished, write some text 
      
    }, 1000);



// Tournament 2

var countDownDate2 = new Date("Aug 28, 2017 01:00:00").getTime();

                                                // Update the count down every 1 second
var x2 = setInterval(function() {

// Get todays date and time
var now2 = new Date().getTime();

// Find the distance between now an the count down date
var distance2 = countDownDate2 - now2;

// Time calculations for days, hours, minutes and seconds
var days2 = Math.floor(distance2 / (1000 * 60 * 60 * 24));
var hours2 = Math.floor((distance2 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes2 = Math.floor((distance2 % (1000 * 60 * 60)) / (1000 * 60));
var seconds2 = Math.floor((distance2 % (1000 * 60)) / 1000);

// Display the result in the element with id="demo"
document.getElementById("days2").innerHTML = days2;
document.getElementById("hours2").innerHTML = hours2;
document.getElementById("minutes2").innerHTML = minutes2;
document.getElementById("seconds2").innerHTML = seconds2;

// If the count down is finished, write some text 
      
    }, 1000);